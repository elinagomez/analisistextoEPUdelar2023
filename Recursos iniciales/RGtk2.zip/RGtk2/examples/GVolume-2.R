(volume_activation_root$hasPrefix(mount_root) ||
 volume_activation_root$equal(mount_root))
