names <- c("gnome-dev-cdrom-audio", "gnome-dev-cdrom", "gnome-dev", "gnome")

icon1 <- gThemedIconNewFromNames(names)
icon2 <- gThemedIconNewWithDefaultCallbacks("gnome-dev-cdrom-audio")
