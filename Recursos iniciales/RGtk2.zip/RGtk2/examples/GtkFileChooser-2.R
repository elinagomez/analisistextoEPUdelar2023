toggle <- gtkCheckButton("Open file read-only")
my_file_chooser$setExtraWidget(toggle)
