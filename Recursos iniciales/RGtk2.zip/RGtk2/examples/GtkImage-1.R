image <- gtkImageNewFromFile("myfile.png")
# or, perhaps more conveniently
image <- gtkImage(file="myfile.png")
